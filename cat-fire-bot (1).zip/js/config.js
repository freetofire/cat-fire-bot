// Firebase Configuration
const firebaseConfig = {
  apiKey: "AIzaSyA7vbuDVd49qNePXsNCJrsMVmj-LCSH3R8",
  authDomain: "cat-fire-bot.firebaseapp.com",
  databaseURL: "https://cat-fire-bot-default-rtdb.firebaseio.com",
  projectId: "cat-fire-bot",
  storageBucket: "cat-fire-bot.firebasestorage.app",
  messagingSenderId: "320717959791",
  appId: "1:320717959791:web:8a6d191972cf263a7d939a",
}

// Telegram Bot Configuration
const TELEGRAM_BOT_CONFIG = {
  botToken: "8343144296:AAGb6BkPFLDTvFEk06aDWfWhFIdh4cF8qjw",
  botUrl: "https://t.me/CatFire_Bot",
  botUsername: "@CatFire_Bot",
  botName: "Cat Fire",
  botId: "8343144296",
}

// Admin Configuration
const ADMIN_CONFIG = {
  adminEmail: "ttsc@gmail.com", // Change this
  adminTelegramId: "7109891636",
}

// App Configuration
const APP_CONFIG = {
  appName: "Cat Fire",
  currency: "$",
  defaultReferrerReward: 2.66,
  defaultRefereeReward: 2.0,
  defaultMinWithdrawal: 5.0,
}
